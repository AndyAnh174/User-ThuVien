"""App package"""
from .main import app
